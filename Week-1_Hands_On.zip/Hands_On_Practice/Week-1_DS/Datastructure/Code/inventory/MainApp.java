package inventory;

public class MainApp {
    public static void main(String[] args) {
        InventoryManager im = new InventoryManager();

        im.addProduct(new Product(1, "Mouse", 50, 299.99));
        im.addProduct(new Product(2, "Keyboard", 30, 799.50));
        im.addProduct(new Product(3, "Monitor", 10, 5499.00));

        im.showAllProducts();

        im.updateProduct(2, 25, 749.99);

        im.deleteProduct(3);

        im.showAllProducts();
    }
}
