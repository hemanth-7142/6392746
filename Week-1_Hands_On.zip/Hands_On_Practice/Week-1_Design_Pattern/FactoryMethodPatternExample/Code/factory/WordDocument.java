package factory;

public class WordDocument implements Document {
    public void open() {
        System.out.println("Opening Word document...");
    }
}
