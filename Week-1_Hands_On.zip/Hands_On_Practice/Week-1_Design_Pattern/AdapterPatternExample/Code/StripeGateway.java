package adapter;

public class StripeGateway {
    public void makeStripePayment(double value) {
        System.out.println("Processing payment through Stripe: ₹" + value);
    }
}
