package inventory;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private Map<Integer, Product> inventory = new HashMap<>();

    public void addProduct(Product p) {
        inventory.put(p.getProductId(), p);
        System.out.println("Product added: " + p);
    }

    public void updateProduct(int id, int newQty, double newPrice) {
        Product p = inventory.get(id);
        if (p != null) {
            p.setQuantity(newQty);
            p.setPrice(newPrice);
            System.out.println("Product updated: " + p);
        } else {
            System.out.println("Product ID " + id + " not found.");
        }
    }

    public void deleteProduct(int id) {
        Product removed = inventory.remove(id);
        if (removed != null) {
            System.out.println("Product deleted: " + removed);
        } else {
            System.out.println("Product ID " + id + " not found.");
        }
    }

    public void showAllProducts() {
        System.out.println("Current Inventory:");
        for (Product p : inventory.values()) {
            System.out.println(p);
        }
    }
}
