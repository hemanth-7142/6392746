package strategy;

public class Main {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        context.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456", "Hemanth"));
        context.executePayment(2500.0);

        System.out.println();

        context.setPaymentStrategy(new PayPalPayment("hemanth@gmail.com"));
        context.executePayment(1800.0);
    }
}
