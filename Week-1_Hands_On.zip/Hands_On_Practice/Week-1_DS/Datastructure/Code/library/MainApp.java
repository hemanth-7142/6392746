package library;

public class MainApp {
    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Wings of Fire", "A.P.J. Abdul Kalam"),
            new Book(2, "Ikigai", "Francesc Miralles"),
            new Book(3, "Do It Today", "Darius Foroux"),
            new Book(4, "Think Like a Monk", "Jay Shetty"),
            new Book(5, "Rich Dad Poor Dad", "Robert Kiyosaki")
        };

        String searchTitle = "Think Like a Monk";

        int linearIndex = LibrarySearch.linearSearch(books, searchTitle);
        if (linearIndex != -1) {
            System.out.println("Linear Search: Found -> " + books[linearIndex]);
        } else {
            System.out.println("Linear Search: Book not found.");
        }

        int binaryIndex = LibrarySearch.binarySearch(books, searchTitle);
        if (binaryIndex != -1) {
            System.out.println("Binary Search: Found -> " + books[binaryIndex]);
        } else {
            System.out.println("Binary Search: Book not found.");
        }
    }
}
