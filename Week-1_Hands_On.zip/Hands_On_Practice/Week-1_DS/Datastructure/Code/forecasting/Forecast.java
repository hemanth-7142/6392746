package forecasting;

public class Forecast {

    public static double futureValue(double currentValue, double rate, int years) {
        if (years == 0) return currentValue;
        return futureValue(currentValue * (1 + rate), rate, years - 1);
    }

    public static double futureValueIterative(double currentValue, double rate, int years) {
        for (int i = 0; i < years; i++) {
            currentValue *= (1 + rate);
        }
        return currentValue;
    }
}
