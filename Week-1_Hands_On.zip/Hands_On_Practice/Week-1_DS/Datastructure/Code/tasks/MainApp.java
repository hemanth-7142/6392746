package tasks;

public class MainApp {
    public static void main(String[] args) {
        TaskList list = new TaskList();

        list.addTask(new Task(1, "Design database", "Pending"));
        list.addTask(new Task(2, "Implement login", "In Progress"));
        list.addTask(new Task(3, "Write unit tests", "Pending"));

        list.displayTasks();

        Task t = list.searchTask(2);
        if (t != null) {
            System.out.println("Found: " + t);
        } else {
            System.out.println("Task not found.");
        }

        list.deleteTask(2);
        list.displayTasks();
    }
}
