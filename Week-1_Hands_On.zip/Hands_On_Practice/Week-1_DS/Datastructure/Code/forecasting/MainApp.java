package forecasting;

public class MainApp {
    public static void main(String[] args) {
        double presentValue = 10000; 
        double annualRate = 0.08;    
        int years = 5;

        double futureRecursive = Forecast.futureValue(presentValue, annualRate, years);
        System.out.println("Future Value (Recursive): ₹" + futureRecursive);

        double futureIterative = Forecast.futureValueIterative(presentValue, annualRate, years);
        System.out.println("Future Value (Iterative): ₹" + futureIterative);
    }
}
