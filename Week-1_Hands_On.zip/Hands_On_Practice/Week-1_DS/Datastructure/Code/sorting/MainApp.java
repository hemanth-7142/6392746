package sorting;

public class MainApp {
    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "Nitish", 4500.0),
            new Order(2, "Rahul", 7999.0),
            new Order(3, "Rishita", 2999.0),
            new Order(4, "Kiran", 9999.0),
            new Order(5, "Swathi", 5499.0)
        };

        System.out.println("Original Orders:");
        OrderSorter.displayOrders(orders);

        System.out.println("\nOrders Sorted by Bubble Sort:");
        OrderSorter.bubbleSort(orders);
        OrderSorter.displayOrders(orders);

        orders = new Order[] {
            new Order(1, "Nitish", 4500.0),
            new Order(2, "Rahul", 7999.0),
            new Order(3, "Rishita", 2999.0),
            new Order(4, "Kiran", 9999.0),
            new Order(5, "Swathi", 5499.0)
        };

        System.out.println("\nOrders Sorted by Quick Sort:");
        OrderSorter.quickSort(orders, 0, orders.length - 1);
        OrderSorter.displayOrders(orders);
    }
}
