package tasks;

public class TaskList {
    private Task head;

    public void addTask(Task newTask) {
        if (head == null) {
            head = newTask;
        } else {
            Task temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newTask;
        }
        System.out.println("Added: " + newTask);
    }

    public Task searchTask(int taskId) {
        Task temp = head;
        while (temp != null) {
            if (temp.taskId == taskId) return temp;
            temp = temp.next;
        }
        return null;
    }

    public void deleteTask(int taskId) {
        if (head == null) return;

        if (head.taskId == taskId) {
            head = head.next;
            System.out.println("Task " + taskId + " deleted.");
            return;
        }

        Task current = head;
        while (current.next != null && current.next.taskId != taskId) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
            System.out.println("Task " + taskId + " deleted.");
        } else {
            System.out.println("Task ID " + taskId + " not found.");
        }
    }

    public void displayTasks() {
        Task temp = head;
        System.out.println("Current Tasks:");
        while (temp != null) {
            System.out.println(temp);
            temp = temp.next;
        }
    }
}
