package employee;

public class MainApp {
    public static void main(String[] args) {
        EmployeeManager em = new EmployeeManager();

        em.addEmployee(new Employee(101, "Alekya", "Developer", 50000.0));
        em.addEmployee(new Employee(102, "Kiran", "Manager", 65000.0));
        em.addEmployee(new Employee(103, "Neha", "Tester", 45000.0));

        em.displayAllEmployees();

        Employee found = em.searchEmployee(102);
        if (found != null) {
            System.out.println("Found: " + found);
        } else {
            System.out.println("Employee not found.");
        }

        em.deleteEmployee(101);
        em.displayAllEmployees();
    }
}
