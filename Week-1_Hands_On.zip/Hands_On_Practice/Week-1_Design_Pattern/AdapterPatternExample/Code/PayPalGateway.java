package adapter;

public class PayPalGateway {
    public void sendPayPalPayment(double cash) {
        System.out.println("Processing payment through PayPal: ₹" + cash);
    }
}
