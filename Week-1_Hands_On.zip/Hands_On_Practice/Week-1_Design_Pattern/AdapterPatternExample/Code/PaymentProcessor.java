package adapter;

public interface PaymentProcessor {
    void processPayment(double amount);
}
