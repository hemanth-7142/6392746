package di;

import java.util.HashMap;
import java.util.Map;

public class CustomerRepositoryImpl implements CustomerRepository {
    private Map<String, Customer> customerDB = new HashMap<>();

    public CustomerRepositoryImpl() {
        customerDB.put("C205", new Customer("C205", "Neeraj"));
        customerDB.put("C207", new Customer("C307", "Rahul"));
    }

    @Override
    public Customer findCustomerById(String id) {
        return customerDB.get(id);
    }
}
