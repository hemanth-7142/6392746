package observer;

public class Main {
    public static void main(String[] args) {
        StockMarket market = new StockMarket();

        Observer mobileUser = new MobileApp("Ram");
        Observer webUser = new WebApp("Rahul");

        market.registerObserver(mobileUser);
        market.registerObserver(webUser);

        market.setStockData("Cognizant", 3725.50);
        System.out.println();
        market.setStockData("Infosys", 1588.25);

        market.removeObserver(webUser);
        System.out.println();
        market.setStockData("HDFC Bank", 1630.00);
    }
}
