package search;

public class MainApp {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Mouse", "Accessories"),
            new Product(103, "Chair", "Furniture"),
            new Product(104, "Keyboard", "Accessories"),
            new Product(105, "Monitor", "Electronics")
        };

        int indexLinear = SearchOperations.linearSearch(products, "Keyboard");
        if (indexLinear != -1)
            System.out.println("Linear Search: Found at index " + indexLinear + ": " + products[indexLinear]);
        else
            System.out.println("Linear Search: Product not found.");

        int indexBinary = SearchOperations.binarySearch(products, "Keyboard");
        if (indexBinary != -1)
            System.out.println("Binary Search: Found at index " + indexBinary + ": " + products[indexBinary]);
        else
            System.out.println("Binary Search: Product not found.");
    }
}
